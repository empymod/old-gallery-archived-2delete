"""
4. Gradient of the misfit function
==================================

TODO: An example how to use the new :func:`emg3d.optimize.gradient` routine
to compute the adjoint-state gradient of the misfit function.


"""
import emg3d
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import LogNorm, SymLogNorm
# plt.style.use('ggplot')


###############################################################################

emg3d.Report()
