"""
2. Simulation
=============

TODO: An example how to use the new :class:`emg3d.surveys.Survey`- and
:class:`emg3d.simulations.Simulation`-classes to model data for an entire
survey.

"""
import emg3d
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import LogNorm, SymLogNorm
# plt.style.use('ggplot')


###############################################################################

emg3d.Report()
