"""
4. Adjoint-state vs. FD gradient
================================

TODO: A comparison of the adjoint-state gradient of the misfit function vs a
finite-difference gradient of the misfit function.

"""
import emg3d
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import LogNorm, SymLogNorm
# plt.style.use('ggplot')


###############################################################################

emg3d.Report()
