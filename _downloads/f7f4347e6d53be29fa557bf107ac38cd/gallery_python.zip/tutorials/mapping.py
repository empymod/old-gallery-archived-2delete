"""
3. Model property mapping
=========================

TODO: Example of the different :class:`emg3d.models.Model`-mappings.

"""
import emg3d
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import LogNorm, SymLogNorm
# plt.style.use('ggplot')


###############################################################################

emg3d.Report()
